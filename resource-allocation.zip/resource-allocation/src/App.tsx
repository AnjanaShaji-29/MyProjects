import React from 'react';
import './App.scss';
import PageTimesheet from './pages/timesheet/index.tsx';

function App() {
  return (
    <div className="App">
      <PageTimesheet />
    </div>
  );
}

export default App;
